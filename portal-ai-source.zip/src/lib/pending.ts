import type { FileUIPart } from "ai";

export type PendingMessage = { text: string; files: FileUIPart[] };

/** First message typed on the new-chat screen, handed to the thread page after navigation. */
const pending = new Map<string, PendingMessage>();

export const setPendingMessage = (id: string, msg: PendingMessage) => pending.set(id, msg);

export function takePendingMessage(id: string): PendingMessage | undefined {
  const msg = pending.get(id);
  pending.delete(id);
  return msg;
}
