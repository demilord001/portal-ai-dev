import { createOpenAI } from "@ai-sdk/openai";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import {
  convertToModelMessages,
  stepCountIs,
  streamText,
  tool,
  APICallError,
  type UIMessage,
  type FileUIPart,
} from "ai";
import { z } from "zod";

import type { Database, Json } from "@/integrations/supabase/types";
import { buildSystemPrompt } from "@/lib/persona";
import { tavilySearch } from "@/lib/tavily.server";
import { ATTACHMENT_BUCKET, isStoredFileUrl, storagePathFromUrl } from "@/lib/attachments";
import {
  createLovableAiGatewayRunIdFetch,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "@/lib/ai/run-id.server";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
const CHAT_MODEL = "openai/gpt-6-astra";
const TRANSCRIBE_MODEL = "openai/gpt-transcribe";

type DB = SupabaseClient<Database>;

const json = (status: number, error: string) =>
  new Response(JSON.stringify({ error }), {
    status,
    headers: { "Content-Type": "application/json" },
  });

async function authenticate(request: Request) {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("Backend is not configured");
  const auth = request.headers.get("authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token || token.split(".").length !== 3) return null;
  const supabase = createClient<Database>(url, key, {
    global: {
      headers: { Authorization: `Bearer ${token}` },
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await supabase.auth.getClaims(token);
  if (error || !data?.claims?.sub) return null;
  return { supabase, userId: data.claims.sub as string };
}

function toBase64(buf: ArrayBuffer) {
  const bytes = new Uint8Array(buf);
  let bin = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

const TEXT_LIKE = /^(text\/|application\/(json|xml|x-yaml|yaml|javascript|typescript|csv))/;
const TEXT_EXT = /\.(md|csv|json|txt|xml|ya?ml|js|ts|tsx|py|html|css)$/i;

async function transcribeAudio(apiKey: string, blob: Blob, filename: string, mediaType: string) {
  const form = new FormData();
  form.append("model", TRANSCRIBE_MODEL);
  form.append("file", new File([blob], filename, { type: mediaType.startsWith("audio/") ? mediaType : "audio/mpeg" }));
  form.append("response_format", "json");
  form.append("stream", "true");
  const res = await fetch(`${GATEWAY_URL}/audio/transcriptions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
  });
  if (!res.ok || !res.body) {
    const body = await res.text().catch(() => "");
    console.error(`Transcription failed [${res.status}]: ${body}`);
    throw new Error(`Transcription failed [${res.status}]`);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let deltas = "";
  let final: string | null = null;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      try {
        const evt = JSON.parse(data) as { type?: string; delta?: string; text?: string };
        if (evt.type === "transcript.text.delta" && evt.delta) deltas += evt.delta;
        if (evt.type === "transcript.text.done" && typeof evt.text === "string") final = evt.text;
      } catch {
        /* ignore partial lines */
      }
    }
  }
  return (final ?? deltas).trim();
}

/** Resolves stored attachments into content the model can read. */
async function resolveAttachments(messages: UIMessage[], supabase: DB, apiKey: string): Promise<UIMessage[]> {
  return Promise.all(messages.map(async (msg) => {
    const parts: UIMessage["parts"] = [];
    for (const part of msg.parts) {
      if (part.type !== "file" || !isStoredFileUrl((part as FileUIPart).url)) {
        parts.push(part);
        continue;
      }
      const file = part as FileUIPart;
      const path = storagePathFromUrl(file.url);
      const name = file.filename ?? path.split("/").pop() ?? "file";
      const mediaType = file.mediaType || "application/octet-stream";
      try {
        if (mediaType.startsWith("audio/")) {
          const { data: row } = await supabase
            .from("attachments")
            .select("transcript")
            .eq("storage_path", path)
            .maybeSingle();
          let transcript = row?.transcript ?? null;
          if (!transcript) {
            const { data: blob, error } = await supabase.storage.from(ATTACHMENT_BUCKET).download(path);
            if (error || !blob) throw new Error(error?.message ?? "download failed");
            transcript = await transcribeAudio(apiKey, blob, name, mediaType);
            await supabase.from("attachments").update({ transcript }).eq("storage_path", path);
          }
          parts.push({
            type: "text",
            text: `[Attached audio file "${name}" — transcript]\n${transcript || "(no speech detected)"}`,
          });
          continue;
        }
        const { data: blob, error } = await supabase.storage.from(ATTACHMENT_BUCKET).download(path);
        if (error || !blob) throw new Error(error?.message ?? "download failed");
        if (TEXT_LIKE.test(mediaType) || TEXT_EXT.test(name)) {
          const text = (await blob.text()).slice(0, 120_000);
          parts.push({ type: "text", text: `[Attached file "${name}"]\n\`\`\`\n${text}\n\`\`\`` });
          continue;
        }
        if (mediaType.startsWith("image/") || mediaType === "application/pdf") {
          const b64 = toBase64(await blob.arrayBuffer());
          parts.push({ type: "file", mediaType, filename: name, url: `data:${mediaType};base64,${b64}` });
          continue;
        }
        parts.push({ type: "text", text: `[Attached file "${name}" (${mediaType}) — this format can't be read]` });
      } catch (err) {
        console.error("Attachment resolve failed", path, err);
        parts.push({ type: "text", text: `[Attached file "${name}" could not be loaded]` });
      }
    }
    return { ...msg, parts };
  }));
}

function friendlyError(error: unknown): string {
  if (APICallError.isInstance(error)) {
    if (error.statusCode === 429) return "PORTAL.AI is getting a lot of requests. Please try again in a moment.";
    if (error.statusCode === 402) return "AI credits are used up for this workspace. Add credits to keep chatting.";
    if (error.statusCode === 403) return "This request was blocked by the AI provider.";
    try {
      const body = JSON.parse(error.responseBody ?? "{}") as { error?: { message?: string }; message?: string };
      return body.error?.message ?? body.message ?? error.message;
    } catch {
      return error.message;
    }
  }
  if (error instanceof Error) return error.message;
  return "Something went wrong. Please try again.";
}

const bodySchema = z.object({
  conversationId: z.string().uuid(),
  messages: z.array(z.any()).min(1).max(400),
});

export async function handleChat(request: Request): Promise<Response> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) return json(500, "AI is not configured.");

  const auth = await authenticate(request);
  if (!auth) return json(401, "Please sign in again.");
  const { supabase, userId } = auth;

  const parsed = bodySchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return json(400, "Invalid request.");
  const { conversationId } = parsed.data;
  const messages = parsed.data.messages as UIMessage[];

  const { data: convo } = await supabase
    .from("conversations")
    .select("id, title")
    .eq("id", conversationId)
    .maybeSingle();
  if (!convo) return json(404, "Conversation not found.");

  const last = messages[messages.length - 1];
  if (last?.role !== "user") return json(400, "Last message must be from the user.");

  const { error: saveErr } = await supabase.from("messages").upsert(
    {
      conversation_id: conversationId,
      user_id: userId,
      ui_id: last.id,
      role: "user",
      parts: last.parts as unknown as Json,
    },
    { onConflict: "conversation_id,ui_id", ignoreDuplicates: true },
  );
  if (saveErr) {
    console.error("Saving user message failed", saveErr);
    return json(500, "Could not save your message.");
  }

  if (convo.title === "New chat") {
    const firstText = last.parts.find((p) => p.type === "text") as { text?: string } | undefined;
    const title = (firstText?.text ?? "").replace(/\s+/g, " ").trim().slice(0, 60);
    if (title) void supabase.from("conversations").update({ title }).eq("id", conversationId).then(() => {});
  }

  const [{ data: profile }, resolved] = await Promise.all([
    supabase.from("profiles").select("first_name").eq("id", userId).maybeSingle(),
    resolveAttachments(messages, supabase, apiKey),
  ]);
  const modelMessages = await convertToModelMessages(resolved);

  const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
  const provider = createOpenAI({
    baseURL: GATEWAY_URL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });

  const result = streamText({
    model: provider.responses(CHAT_MODEL),
    instructions: buildSystemPrompt(new Date(), profile?.first_name),
    messages: modelMessages,
    abortSignal: request.signal,
    stopWhen: stepCountIs(6),
    tools: {
      web_search: tool({
        description:
          "Search the live web for real-time or current information (news, prices, weather, recent events, current facts). Do not use for general knowledge, reasoning, coding or writing.",
        inputSchema: z.object({
          query: z.string().describe("A focused web search query"),
        }),
        execute: async ({ query }) => tavilySearch(query, request.signal),
      }),
    },
    providerOptions: {
      openai: {
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        store: false,
        include: ["reasoning.encrypted_content"],
      },
    },
  });

  const response = result.toUIMessageStreamResponse({
    originalMessages: messages,
    sendReasoning: true,
    onError: (error) => {
      console.error("Chat stream error", error);
      return friendlyError(error);
    },
    onFinish: async ({ responseMessage, isAborted }) => {
      if (!responseMessage.parts.length) return;
      const { error } = await supabase.from("messages").upsert(
        {
          conversation_id: conversationId,
          user_id: userId,
          ui_id: responseMessage.id,
          role: "assistant",
          parts: responseMessage.parts as unknown as Json,
        },
        { onConflict: "conversation_id,ui_id" },
      );
      if (error) console.error("Saving assistant message failed", error, { isAborted });
      await supabase
        .from("conversations")
        .update({ updated_at: new Date().toISOString() })
        .eq("id", conversationId);
    },
  });

  return withLovableAiGatewayRunIdHeader(response, runIdFetch);
}
