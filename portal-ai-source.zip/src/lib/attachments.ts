import { supabase } from "@/integrations/supabase/client";
import type { FileUIPart } from "ai";

/** Stored file parts point at private storage with this scheme instead of a URL. */
export const STORAGE_SCHEME = "portal-file://";
export const ATTACHMENT_BUCKET = "attachments";
export const MAX_FILE_BYTES = 20 * 1024 * 1024;
export const ACCEPTED_FILES =
  "image/*,audio/*,application/pdf,text/*,.md,.csv,.json,.txt,.xml,.yaml,.yml,.js,.ts,.tsx,.py,.html,.css";

export const isStoredFileUrl = (url: string) => url.startsWith(STORAGE_SCHEME);
export const storagePathFromUrl = (url: string) => url.slice(STORAGE_SCHEME.length);

function dataUrlToBlob(dataUrl: string, mediaType: string): Blob {
  const base64 = dataUrl.split(",")[1] ?? "";
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mediaType });
}

/** Uploads composer files to private storage and returns file parts that reference them. */
export async function uploadAttachments(
  files: FileUIPart[],
  userId: string,
  conversationId: string,
): Promise<FileUIPart[]> {
  return Promise.all(files.map(async (file): Promise<FileUIPart> => {
    if (isStoredFileUrl(file.url)) return file;
    const mediaType = file.mediaType || "application/octet-stream";
    const blob = file.url.startsWith("data:")
      ? dataUrlToBlob(file.url, mediaType)
      : await (await fetch(file.url)).blob();
    if (blob.size > MAX_FILE_BYTES) throw new Error(`${file.filename ?? "File"} is larger than 20 MB.`);
    const safeName = (file.filename ?? "file").replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
    const path = `${userId}/${conversationId}/${crypto.randomUUID()}-${safeName}`;
    const { error } = await supabase.storage
      .from(ATTACHMENT_BUCKET)
      .upload(path, blob, { contentType: mediaType, upsert: false });
    if (error) throw new Error(`Upload failed: ${error.message}`);
    const { error: rowError } = await supabase.from("attachments").insert({
      user_id: userId,
      conversation_id: conversationId,
      storage_path: path,
      filename: file.filename ?? safeName,
      media_type: mediaType,
      size_bytes: blob.size,
    });
    if (rowError) throw new Error(`Could not save attachment: ${rowError.message}`);
    return { type: "file", mediaType, filename: file.filename ?? safeName, url: STORAGE_SCHEME + path };
  }));
}

const signedCache = new Map<string, { url: string; exp: number }>();

export async function getSignedUrl(path: string): Promise<string | null> {
  const hit = signedCache.get(path);
  if (hit && hit.exp > Date.now()) return hit.url;
  const { data, error } = await supabase.storage.from(ATTACHMENT_BUCKET).createSignedUrl(path, 3600);
  if (error || !data) return null;
  signedCache.set(path, { url: data.signedUrl, exp: Date.now() + 50 * 60 * 1000 });
  return data.signedUrl;
}
