export type WebSearchResult = {
  query: string;
  answer: string | null;
  results: { title: string; url: string; content: string }[];
};

export async function tavilySearch(query: string, signal?: AbortSignal): Promise<WebSearchResult> {
  const key = process.env["TAVILY_API_KEY"];
  if (!key) throw new Error("Web search is not configured (missing TAVILY_API_KEY).");
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      query,
      search_depth: "basic",
      max_results: 6,
      include_answer: true,
    }),
    signal: signal ?? null,
  });
  if (!res.ok) {
    const body = await res.text();
    console.error(`Tavily search failed [${res.status}]: ${body}`);
    throw new Error(`Web search failed [${res.status}]`);
  }
  const json = (await res.json()) as {
    answer?: string;
    results?: { title?: string; url?: string; content?: string }[];
  };
  return {
    query,
    answer: json.answer ?? null,
    results: (json.results ?? []).map((r) => ({
      title: r.title ?? r.url ?? "Untitled",
      url: r.url ?? "",
      content: (r.content ?? "").slice(0, 1200),
    })),
  };
}
