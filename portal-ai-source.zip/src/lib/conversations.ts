import { queryOptions } from "@tanstack/react-query";
import type { UIMessage } from "ai";
import { supabase } from "@/integrations/supabase/client";

export const conversationsQuery = queryOptions({
  queryKey: ["conversations"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("conversations")
      .select("id, title, updated_at")
      .order("updated_at", { ascending: false })
      .limit(200);
    if (error) throw error;
    return data;
  },
});

export const messagesQuery = (conversationId: string) =>
  queryOptions({
    queryKey: ["messages", conversationId],
    staleTime: Infinity,
    queryFn: async (): Promise<UIMessage[]> => {
      const { data: convo, error: cErr } = await supabase
        .from("conversations")
        .select("id")
        .eq("id", conversationId)
        .maybeSingle();
      if (cErr) throw cErr;
      if (!convo) throw new Error("not_found");
      const { data, error } = await supabase
        .from("messages")
        .select("ui_id, role, parts, created_at")
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data.map((m) => ({
        id: m.ui_id,
        role: m.role as UIMessage["role"],
        parts: m.parts as unknown as UIMessage["parts"],
      }));
    },
  });

export async function createConversation(userId: string, title = "New chat") {
  const { data, error } = await supabase
    .from("conversations")
    .insert({ user_id: userId, title })
    .select("id")
    .single();
  if (error) throw error;
  return data.id;
}
