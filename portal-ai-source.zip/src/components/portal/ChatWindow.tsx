import { useChat } from "@ai-sdk/react";
import { useQueryClient } from "@tanstack/react-query";
import { DefaultChatTransport, type UIMessage } from "ai";
import { Copy, RotateCcw } from "lucide-react";
import { useEffect, useMemo, useRef } from "react";
import { toast } from "sonner";

import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import { Message, MessageAction, MessageActions, MessageContent } from "@/components/ai-elements/message";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { supabase } from "@/integrations/supabase/client";
import { uploadAttachments } from "@/lib/attachments";
import { takePendingMessage } from "@/lib/pending";
import { AssistantParts, FileAttachment } from "./MessageParts";
import { Composer } from "./Composer";
import { Greeting } from "./Greeting";
import { PortalMark } from "./PortalLogo";

async function authHeaders(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function ChatWindow({
  conversationId,
  userId,
  firstName,
  initialMessages,
}: {
  conversationId: string;
  userId: string;
  firstName?: string | null | undefined;
  initialMessages: UIMessage[];
}) {
  const queryClient = useQueryClient();
  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        headers: authHeaders,
        body: { conversationId },
      }),
    [conversationId],
  );

  const { messages, sendMessage, status, stop, error, regenerate } = useChat({
    id: conversationId,
    messages: initialMessages,
    transport,
    onError: (err) => {
      let msg = err.message;
      try {
        msg = (JSON.parse(err.message) as { error?: string }).error ?? msg;
      } catch {
        /* plain message */
      }
      toast.error(msg || "Something went wrong");
    },
    onFinish: () => {
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
  });

  useEffect(() => {
    queryClient.setQueryData(["messages", conversationId], messages);
  }, [messages, conversationId, queryClient]);

  const startedRef = useRef(false);
  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    const pending = takePendingMessage(conversationId);
    if (pending) {
      sendMessage({ text: pending.text, files: pending.files });
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    }
  }, [conversationId, sendMessage, queryClient]);

  const busy = status === "submitted" || status === "streaming";
  const last = messages[messages.length - 1];
  const waiting = busy && (last?.role === "user" || !last?.parts.some((p) => p.type === "text" && p.text));

  return (
    <div className="flex h-full min-h-0 flex-col">
      <Conversation className="min-h-0 flex-1">
        <ConversationContent className="mx-auto w-full max-w-3xl gap-6 px-3 pb-10 pt-4 sm:gap-7 sm:px-4 sm:pt-6">
          {messages.length === 0 && !busy && (
            <div className="pt-[10vh] sm:pt-[18vh]">
              <Greeting name={firstName} />
            </div>
          )}
          {messages.map((m, idx) => {
            const isLast = idx === messages.length - 1;
            if (m.role === "user") {
              const files = m.parts.filter((p) => p.type === "file");
              const text = m.parts
                .filter((p) => p.type === "text")
                .map((p) => (p as { text: string }).text)
                .join("\n");
              return (
                <Message key={m.id} from="user" className="flex-col items-end gap-2">
                  {files.length > 0 && (
                    <div className="flex flex-wrap justify-end gap-2">
                      {files.map((f, i) => (
                        <FileAttachment key={i} part={f} />
                      ))}
                    </div>
                  )}
                  {text && (
                    <MessageContent className="bubble-3d max-w-[85%] rounded-3xl rounded-br-lg bg-user-bubble px-4 py-2.5 text-user-bubble-foreground">
                      <p className="whitespace-pre-wrap text-[15px] leading-relaxed">{text}</p>
                    </MessageContent>
                  )}
                </Message>
              );
            }
            return (
              <Message key={m.id} from="assistant" className="items-start gap-3">
                <PortalMark className={`mt-0.5 size-7 shrink-0 ${isLast && busy ? "animate-spin [animation-duration:3s]" : ""}`} />
                <div className="min-w-0 flex-1">
                  <MessageContent className="w-full max-w-none bg-transparent p-0 text-[15px] leading-relaxed">
                    <AssistantParts message={m} streaming={isLast && status === "streaming"} />
                  </MessageContent>
                  {!(isLast && busy) && (
                    <MessageActions className="mt-2 opacity-70 transition-opacity hover:opacity-100">
                      <MessageAction
                        tooltip="Copy"
                        label="Copy"
                        onClick={() => {
                          const t = m.parts.filter((p) => p.type === "text").map((p) => (p as { text: string }).text).join("\n\n");
                          navigator.clipboard.writeText(t);
                          toast.success("Copied");
                        }}
                      >
                        <Copy className="size-3.5" />
                      </MessageAction>
                      {isLast && (
                        <MessageAction tooltip="Regenerate" label="Regenerate" onClick={() => regenerate()}>
                          <RotateCcw className="size-3.5" />
                        </MessageAction>
                      )}
                    </MessageActions>
                  )}
                </div>
              </Message>
            );
          })}
          {waiting && last?.role === "user" && (
            <div className="flex items-center gap-3">
              <PortalMark className="size-7 animate-spin [animation-duration:3s]" />
              <Shimmer>Thinking…</Shimmer>
            </div>
          )}
          {error && !busy && (
            <div className="flex items-center gap-3 rounded-2xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm">
              <span className="flex-1">That response didn't finish.</span>
              <button className="font-medium underline-offset-4 hover:underline" onClick={() => regenerate()}>
                Try again
              </button>
            </div>
          )}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>

      <div className="mx-auto w-full max-w-3xl px-3 pb-[max(1rem,env(safe-area-inset-bottom))] sm:px-4">
        <Composer
          status={status}
          onStop={stop}
          autoFocusKey={conversationId}
          onSubmit={async (msg) => {
            const files = msg.files.length ? await uploadAttachments(msg.files, userId, conversationId) : [];
            sendMessage(files.length ? { text: msg.text, files } : { text: msg.text });
          }}
        />
        <p className="mt-2 text-center text-[11px] text-muted-foreground">
          PORTAL.AI can make mistakes. Check important info.
        </p>
      </div>
    </div>
  );
}
