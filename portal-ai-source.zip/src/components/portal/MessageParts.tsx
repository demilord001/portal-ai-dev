import type { FileUIPart, UIMessage } from "ai";
import { FileText, Globe, Music2 } from "lucide-react";
import { useEffect, useState } from "react";

import { MessageResponse } from "@/components/ai-elements/message";
import { Reasoning, ReasoningContent, ReasoningTrigger } from "@/components/ai-elements/reasoning";
import { Tool, ToolContent, ToolHeader, ToolInput } from "@/components/ai-elements/tool";
import { getSignedUrl, isStoredFileUrl, storagePathFromUrl } from "@/lib/attachments";
import type { WebSearchResult } from "@/lib/tavily.server";

function useFileUrl(url: string) {
  const [resolved, setResolved] = useState<string | null>(isStoredFileUrl(url) ? null : url);
  useEffect(() => {
    if (!isStoredFileUrl(url)) return;
    let alive = true;
    getSignedUrl(storagePathFromUrl(url)).then((u) => alive && setResolved(u));
    return () => {
      alive = false;
    };
  }, [url]);
  return resolved;
}

export function FileAttachment({ part }: { part: FileUIPart }) {
  const url = useFileUrl(part.url);
  const name = part.filename ?? "Attachment";
  if (part.mediaType?.startsWith("image/")) {
    return url ? (
      <a href={url} target="_blank" rel="noreferrer">
        <img src={url} alt={name} className="max-h-60 max-w-full rounded-2xl border border-border object-cover" />
      </a>
    ) : (
      <div className="h-40 w-56 animate-pulse rounded-2xl bg-secondary" />
    );
  }
  if (part.mediaType?.startsWith("audio/")) {
    return (
      <div className="flex w-72 max-w-full flex-col gap-2 rounded-2xl border border-border bg-secondary/60 p-3">
        <span className="flex items-center gap-2 text-xs text-muted-foreground">
          <Music2 className="size-4 text-brand-coral" /> <span className="truncate">{name}</span>
        </span>
        {url && <audio controls src={url} className="h-9 w-full" />}
      </div>
    );
  }
  return (
    <a
      href={url ?? undefined}
      target="_blank"
      rel="noreferrer"
      className="flex max-w-xs items-center gap-2.5 rounded-2xl border border-border bg-secondary/60 px-3 py-2.5 text-sm hover:bg-secondary"
    >
      <FileText className="size-5 shrink-0 text-brand-cyan" />
      <span className="truncate">{name}</span>
    </a>
  );
}

function SearchResults({ output }: { output: WebSearchResult }) {
  return (
    <div className="space-y-2 p-4 pt-0">
      {output.results.map((r) => (
        <a
          key={r.url}
          href={r.url}
          target="_blank"
          rel="noreferrer"
          className="block rounded-xl border border-border bg-background/40 px-3 py-2 transition-colors hover:bg-accent"
        >
          <div className="truncate text-sm font-medium">{r.title}</div>
          <div className="truncate text-xs text-muted-foreground">{r.url.replace(/^https?:\/\//, "")}</div>
        </a>
      ))}
    </div>
  );
}

export function AssistantParts({ message, streaming }: { message: UIMessage; streaming: boolean }) {
  const lastIdx = message.parts.length - 1;
  return (
    <div className="flex flex-col gap-3">
      {message.parts.map((part, i) => {
        switch (part.type) {
          case "text":
            return (
              <MessageResponse key={i} className="portal-prose">
                {part.text}
              </MessageResponse>
            );
          case "reasoning":
            if (!part.text.trim()) return null;
            return (
              <Reasoning key={i} isStreaming={streaming && i === lastIdx} defaultOpen={false}>
                <ReasoningTrigger />
                <ReasoningContent>{part.text}</ReasoningContent>
              </Reasoning>
            );
          case "tool-web_search": {
            const input = part.input as { query?: string } | undefined;
            return (
              <Tool key={i} defaultOpen={false} className="mb-0 rounded-2xl border-border bg-card/50">
                <ToolHeader
                  type={part.type}
                  state={part.state}
                  title={
                    part.state === "output-available"
                      ? `Searched the web${input?.query ? `: “${input.query}”` : ""}`
                      : "Searching the web…"
                  }
                />
                <ToolContent>
                  {input && <ToolInput input={input} />}
                  {part.state === "output-available" && <SearchResults output={part.output as WebSearchResult} />}
                  {part.state === "output-error" && (
                    <p className="p-4 pt-0 text-sm text-destructive">{part.errorText}</p>
                  )}
                </ToolContent>
              </Tool>
            );
          }
          case "file":
            return <FileAttachment key={i} part={part} />;
          default:
            return null;
        }
      })}
    </div>
  );
}

export function SearchingBadge() {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
      <Globe className="size-3.5 animate-pulse text-brand-cyan" /> Searching the web
    </span>
  );
}
