import type { ChatStatus } from "ai";
import { FileText, Music2, Paperclip, X } from "lucide-react";
import { toast } from "sonner";
import { useEffect, useRef } from "react";

import {
  PromptInput,
  PromptInputButton,
  PromptInputFooter,
  PromptInputHeader,
  PromptInputSubmit,
  PromptInputTextarea,
  PromptInputTools,
  usePromptInputAttachments,
  type PromptInputMessage,
} from "@/components/ai-elements/prompt-input";
import { ACCEPTED_FILES, MAX_FILE_BYTES } from "@/lib/attachments";

function AttachmentChips() {
  const { files, remove } = usePromptInputAttachments();
  if (!files.length) return null;
  return (
    <PromptInputHeader className="flex flex-wrap gap-2 px-3 pt-3">
      {files.map((f) => {
        const isImage = f.mediaType?.startsWith("image/");
        const isAudio = f.mediaType?.startsWith("audio/");
        return (
          <div key={f.id} className="group relative flex items-center gap-2 rounded-xl border border-border bg-secondary/70 py-1.5 pl-1.5 pr-7 text-xs">
            {isImage ? (
              <img src={f.url} alt="" className="size-8 rounded-lg object-cover" />
            ) : (
              <span className="grid size-8 place-items-center rounded-lg bg-background/60">
                {isAudio ? <Music2 className="size-4 text-brand-coral" /> : <FileText className="size-4 text-brand-cyan" />}
              </span>
            )}
            <span className="max-w-36 truncate">{f.filename}</span>
            <button
              type="button"
              aria-label={`Remove ${f.filename}`}
              onClick={() => remove(f.id)}
              className="absolute right-1.5 top-1/2 grid size-5 -translate-y-1/2 place-items-center rounded-full text-muted-foreground hover:bg-accent hover:text-foreground"
            >
              <X className="size-3" />
            </button>
          </div>
        );
      })}
    </PromptInputHeader>
  );
}

function AttachButton() {
  const { openFileDialog } = usePromptInputAttachments();
  return (
    <PromptInputButton tooltip="Attach images, documents or audio" onClick={openFileDialog} aria-label="Attach files">
      <Paperclip className="size-4" />
    </PromptInputButton>
  );
}

export function Composer({
  onSubmit,
  status,
  onStop,
  placeholder = "Ask PORTAL anything…",
  autoFocusKey,
}: {
  onSubmit: (msg: PromptInputMessage) => Promise<void>;
  status?: ChatStatus | undefined;
  onStop?: (() => void) | undefined;
  placeholder?: string;
  autoFocusKey?: string | number;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    if (!busy) wrapRef.current?.querySelector("textarea")?.focus();
  }, [busy, autoFocusKey]);

  return (
    <div ref={wrapRef} className="w-full">
      <PromptInput
        accept={ACCEPTED_FILES}
        multiple
        globalDrop
        maxFiles={8}
        maxFileSize={MAX_FILE_BYTES}
        onError={(e) => toast.error(e.message)}
        onSubmit={async (msg) => {
          if (busy) return;
          if (!msg.text.trim() && !msg.files.length) return;
          try {
            await onSubmit(msg);
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "Could not send message");
            throw err;
          }
        }}
        className="glass composer-3d rounded-[1.75rem] shadow-soft [&_[data-slot=input-group]]:rounded-[1.75rem] [&_[data-slot=input-group]]:border-0 [&_[data-slot=input-group]]:bg-transparent"
      >
        <AttachmentChips />
        <PromptInputTextarea placeholder={placeholder} className="min-h-14 px-4 pt-4 text-base sm:px-5 sm:text-[15px]" />
        <PromptInputFooter className="px-3 pb-3">
          <PromptInputTools>
            <AttachButton />
          </PromptInputTools>
          <PromptInputSubmit status={status} onStop={onStop} className="rounded-full" />
        </PromptInputFooter>
      </PromptInput>
    </div>
  );
}
