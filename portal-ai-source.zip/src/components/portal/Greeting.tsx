import { useEffect, useState } from "react";
import { greetingForHour } from "@/lib/greeting";

export function Greeting({ name }: { name?: string | null | undefined }) {
  const [hello, setHello] = useState<string | null>(null);
  useEffect(() => {
    const update = () => setHello(greetingForHour(new Date().getHours()));
    update();
    const t = setInterval(update, 60_000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="animate-fade-up text-center">
      <h1 className="text-4xl font-semibold leading-tight sm:text-5xl">
        <span className="text-gradient-brand">
          {hello ?? "\u00a0"}
          {hello && name ? `, ${name}` : ""}
        </span>
      </h1>
      <p className="mt-3 text-lg text-muted-foreground sm:text-xl">How can I help you today?</p>
    </div>
  );
}

export const SUGGESTIONS = [
  "What are today's top tech headlines?",
  "Explain the Fourier transform with an equation",
  "Write a Python script that renames files by date",
  "Compare React and Vue in a table",
];
