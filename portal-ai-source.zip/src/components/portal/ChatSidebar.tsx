import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate, useParams } from "@tanstack/react-router";
import { MessageSquare, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { conversationsQuery } from "@/lib/conversations";
import { cn } from "@/lib/utils";

export function ChatSidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { data, isLoading } = useQuery(conversationsQuery);
  const params = useParams({ strict: false }) as { threadId?: string };
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function remove(id: string) {
    const { error } = await supabase.from("conversations").delete().eq("id", id);
    if (error) { toast.error("Could not delete chat"); return; }
    queryClient.invalidateQueries({ queryKey: ["conversations"] });
    queryClient.removeQueries({ queryKey: ["messages", id] });
    if (params.threadId === id) navigate({ to: "/chat" });
  }

  return (
    <div className="flex h-full flex-col">
      <div className="p-3">
        <Button asChild variant="glass" className="h-11 w-full justify-start gap-2 px-4">
          <Link to="/chat" onClick={onNavigate}>
            <Plus /> New chat
          </Link>
        </Button>
      </div>
      <div className="px-5 pb-2 pt-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">Recent</div>
      <nav className="min-h-0 flex-1 space-y-0.5 overflow-y-auto px-2 pb-4">
        {isLoading &&
          Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="mx-2 my-2 h-7 animate-pulse rounded-lg bg-sidebar-accent/60" />
          ))}
        {data?.length === 0 && <p className="px-3 py-2 text-sm text-muted-foreground">No chats yet.</p>}
        {data?.map((c) => (
          <div
            key={c.id}
            className={cn(
              "group flex items-center rounded-full pr-1 transition-colors hover:bg-sidebar-accent",
              params.threadId === c.id && "bg-sidebar-accent",
            )}
          >
            <Link
              to="/chat/$threadId"
              params={{ threadId: c.id }}
              onClick={onNavigate}
              className="flex min-w-0 flex-1 items-center gap-2.5 px-3 py-2 text-sm"
            >
              <MessageSquare className="size-4 shrink-0 text-muted-foreground" />
              <span className="truncate">{c.title}</span>
            </Link>
            <button
              type="button"
              aria-label={`Delete ${c.title}`}
              onClick={() => remove(c.id)}
              className="grid size-7 shrink-0 place-items-center rounded-full text-muted-foreground opacity-0 transition hover:bg-background/60 hover:text-destructive focus:opacity-100 group-hover:opacity-100"
            >
              <Trash2 className="size-3.5" />
            </button>
          </div>
        ))}
      </nav>
      <div className="border-t border-sidebar-border px-5 py-3 text-[11px] text-muted-foreground">
        PORTAL.AI · by Luis Dem at DemLabs
      </div>
    </div>
  );
}
