import logo from "@/assets/portal-logo.png";
import { cn } from "@/lib/utils";

export function PortalMark({ className }: { className?: string }) {
  return <img src={logo} alt="" width={816} height={816} className={cn("size-8 object-contain", className)} />;
}

export function PortalLogo({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <PortalMark className="size-7" />
      {!compact && (
        <span className="font-display text-[15px] font-semibold tracking-tight text-foreground">
          PORTAL<span className="text-gradient-brand">.AI</span>
        </span>
      )}
    </span>
  );
}
