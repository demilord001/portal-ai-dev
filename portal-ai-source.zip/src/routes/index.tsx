import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  AudioLines,
  Code2,
  FileText,
  Globe,
  History,
  ImageIcon,
  Lock,
  Sigma,
  Zap,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { PortalLogo, PortalMark } from "@/components/portal/PortalLogo";
import { useSessionUser } from "@/hooks/use-auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PORTAL.AI — Next-Gen Assistance by DemLabs" },
      {
        name: "description",
        content:
          "PORTAL.AI is your gateway to next-gen AI assistance: live web search, file and audio understanding, rich answers and saved chat history.",
      },
      { property: "og:title", content: "PORTAL.AI — Next-Gen Assistance" },
      {
        property: "og:description",
        content: "Versatile, accurate, intelligent answers with live web search and file understanding.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const DEMOS = [
  {
    prompt: "What's the latest news on renewable energy this week?",
    searched: true,
    answer: "Here's what's new this week, from 5 live sources:\n• Record solar installs reported across Europe\n• New offshore wind auctions announced",
  },
  {
    prompt: "Explain quicksort and show me a Python version",
    searched: false,
    answer: "Quicksort picks a pivot, partitions the list, then sorts each side.\n\ndef quicksort(a): ...",
  },
  {
    prompt: "Summarize this PDF and the voice memo I attached",
    searched: false,
    answer: "The report covers Q3 growth of 18%. In your memo you asked to focus on hiring plans…",
  },
];

function CtaButton({ size = "xl" }: { size?: "xl" | "lg" }) {
  const { user } = useSessionUser();
  return user ? (
    <Button asChild variant="hero" size={size}>
      <Link to="/chat">
        Open PORTAL <ArrowRight />
      </Link>
    </Button>
  ) : (
    <Button asChild variant="hero" size={size}>
      <Link to="/auth">
        Get started free <ArrowRight />
      </Link>
    </Button>
  );
}

function HeroPreview() {
  const [i, setI] = useState(0);
  const [typed, setTyped] = useState("");
  const demo = DEMOS[i] ?? DEMOS[0]!;

  useEffect(() => {
    setTyped("");
    let n = 0;
    const t = setInterval(() => {
      n += 2;
      setTyped(demo.answer.slice(0, n));
      if (n >= demo.answer.length) clearInterval(t);
    }, 28);
    const next = setTimeout(() => setI((v) => (v + 1) % DEMOS.length), 6000);
    return () => {
      clearInterval(t);
      clearTimeout(next);
    };
  }, [i, demo.answer]);

  return (
    <div className="relative mx-auto w-full max-w-2xl animate-fade-up [animation-delay:200ms]">
      <div className="absolute -inset-10 -z-10 rounded-full bg-aurora blur-2xl" />
      <div className="glass ring-gradient rounded-3xl p-5 shadow-soft sm:p-6">
        <div className="mb-4 flex items-center justify-between">
          <PortalLogo />
          <div className="flex gap-1.5">
            {DEMOS.map((_, k) => (
              <button
                key={k}
                aria-label={`Show example ${k + 1}`}
                onClick={() => setI(k)}
                className={`h-1.5 rounded-full transition-all ${k === i ? "w-6 bg-primary" : "w-1.5 bg-muted-foreground/40"}`}
              />
            ))}
          </div>
        </div>
        <div className="space-y-4 text-left">
          <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-md bg-user-bubble px-4 py-2.5 text-sm text-user-bubble-foreground">
            {demo.prompt}
          </div>
          <div className="flex gap-3">
            <PortalMark className="mt-0.5 size-6 shrink-0" />
            <div className="min-h-24 flex-1 text-sm">
              <div className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1 text-xs text-muted-foreground">
                {demo.searched ? (
                  <>
                    <Globe className="size-3.5 text-brand-cyan" /> Searched the web
                  </>
                ) : (
                  <>
                    <Zap className="size-3.5 text-brand-coral" /> Answered instantly — no search needed
                  </>
                )}
              </div>
              <p className="whitespace-pre-line leading-relaxed text-foreground/90">
                {typed}
                <span className="ml-0.5 inline-block h-4 w-[2px] animate-pulse bg-brand-cyan align-middle" />
              </p>
            </div>
          </div>
        </div>
        <div className="mt-5 flex items-center gap-2 rounded-full border border-border bg-background/60 px-4 py-2.5 text-sm text-muted-foreground">
          <span className="flex-1 truncate">Ask PORTAL anything…</span>
          <ImageIcon className="size-4" />
          <AudioLines className="size-4" />
          <span className="grid size-7 place-items-center rounded-full bg-primary text-primary-foreground">
            <ArrowRight className="size-3.5" />
          </span>
        </div>
      </div>
    </div>
  );
}

const FEATURES = [
  { icon: Globe, title: "Smart live search", body: "Searches the web only when your question needs fresh facts — everything else is answered instantly." },
  { icon: FileText, title: "Reads your files", body: "Drop in PDFs, images, spreadsheets or code and ask questions about them." },
  { icon: AudioLines, title: "Understands audio", body: "Attach voice memos or recordings. PORTAL transcribes and reasons over them." },
  { icon: Code2, title: "Beautiful answers", body: "Markdown, syntax-highlighted code, tables and quotes rendered cleanly." },
  { icon: Sigma, title: "Math that renders", body: "Equations display as real math, from quick formulas to full derivations." },
  { icon: History, title: "Every chat saved", body: "Pick up any conversation from your sidebar, on any device." },
];

function Landing() {
  const { user } = useSessionUser();
  const navigate = useNavigate();
  useEffect(() => {
    if (user) navigate({ to: "/chat", replace: true });
  }, [user, navigate]);
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[900px] bg-aurora" />

      <header className="sticky top-0 z-30 border-b border-border/50 bg-background/60 backdrop-blur-xl">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
          <Link to="/">
            <PortalLogo />
          </Link>
          <div className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
            <a href="#features" className="transition-colors hover:text-foreground">Features</a>
            <a href="#search" className="transition-colors hover:text-foreground">Live search</a>
            <a href="#about" className="transition-colors hover:text-foreground">About</a>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm" className="rounded-full">
              <Link to="/auth">Sign in</Link>
            </Button>
            <CtaButton size="lg" />
          </div>
        </nav>
      </header>

      <main>
        <section className="mx-auto max-w-6xl px-5 pb-20 pt-16 text-center sm:pt-24">
          <div className="mx-auto mb-6 inline-flex animate-fade-up items-center gap-2 rounded-full glass px-3.5 py-1.5 text-xs text-muted-foreground">
            <span className="size-1.5 rounded-full bg-brand-cyan" /> Next-Gen Assistance, built by DemLabs
          </div>
          <h1 className="mx-auto max-w-4xl animate-fade-up text-5xl font-semibold leading-[1.05] sm:text-7xl">
            Your portal to{" "}
            <span className="text-gradient-brand animate-shine">next-gen assistance</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl animate-fade-up text-lg text-muted-foreground [animation-delay:100ms]">
            Ask anything. PORTAL.AI reasons, reads your files, listens to your audio and searches the
            live web when it matters — giving you accurate answers in seconds.
          </p>
          <div className="mt-9 flex animate-fade-up flex-wrap items-center justify-center gap-3 [animation-delay:150ms]">
            <CtaButton />
            <Button asChild variant="glass" size="xl">
              <a href="#features">See what it can do</a>
            </Button>
          </div>
          <div className="mt-16">
            <HeroPreview />
          </div>
        </section>

        <section id="features" className="mx-auto max-w-6xl px-5 py-20">
          <h2 className="text-center text-3xl font-semibold sm:text-4xl">One assistant. Every kind of question.</h2>
          <p className="mx-auto mt-3 max-w-xl text-center text-muted-foreground">
            Built for speed, accuracy and depth — so you get more done with less back-and-forth.
          </p>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map(({ icon: Icon, title, body }) => (
              <div
                key={title}
                className="group rounded-3xl border border-border bg-card/60 p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-glow"
              >
                <div className="mb-4 grid size-11 place-items-center rounded-2xl bg-secondary">
                  <Icon className="size-5 text-brand-cyan transition-colors group-hover:text-brand-coral" />
                </div>
                <h3 className="text-lg font-semibold">{title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{body}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="search" className="mx-auto max-w-6xl px-5 py-20">
          <div className="glass grid items-center gap-10 rounded-[2rem] p-8 sm:p-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-semibold sm:text-4xl">
                Searches when it should. <span className="text-gradient-brand">Thinks when it can.</span>
              </h2>
              <p className="mt-4 text-muted-foreground">
                PORTAL decides on every message whether live web results would make the answer better.
                News, prices and current events get fresh sources with citations. Coding, writing and
                reasoning skip the search — so replies stay fast.
              </p>
            </div>
            <div className="space-y-3">
              {[
                { q: "Who won last night's match?", s: true },
                { q: "Rewrite this email to sound friendlier", s: false },
                { q: "Today's EUR to USD rate", s: true },
                { q: "Solve ∫ x² dx from 0 to 3", s: false },
              ].map(({ q, s }) => (
                <div key={q} className="flex items-center justify-between gap-3 rounded-2xl border border-border bg-background/50 px-4 py-3 text-sm">
                  <span className="truncate">{q}</span>
                  <span className={`shrink-0 inline-flex items-center gap-1.5 text-xs ${s ? "text-brand-cyan" : "text-brand-coral"}`}>
                    {s ? <Globe className="size-3.5" /> : <Zap className="size-3.5" />}
                    {s ? "Live search" : "Instant"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="mx-auto max-w-4xl px-5 py-20 text-center">
          <Lock className="mx-auto mb-4 size-6 text-muted-foreground" />
          <h2 className="text-3xl font-semibold sm:text-4xl">Private by design</h2>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Your chats and files are tied to your account and visible only to you. PORTAL.AI is developed
            by Luis Dem at DemLabs.
          </p>
          <div className="mt-10">
            <CtaButton />
          </div>
        </section>
      </main>

      <footer className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-sm text-muted-foreground sm:flex-row">
          <PortalLogo />
          <p>© {new Date().getFullYear()} DemLabs · Built by Luis Dem</p>
        </div>
      </footer>
    </div>
  );
}
