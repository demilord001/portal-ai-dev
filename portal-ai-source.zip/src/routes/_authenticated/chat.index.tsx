import { useQueryClient } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Globe, Code2, Sigma, Table2 } from "lucide-react";

import { Composer } from "@/components/portal/Composer";
import { Greeting, SUGGESTIONS } from "@/components/portal/Greeting";
import { useProfile } from "@/hooks/use-auth";
import { uploadAttachments } from "@/lib/attachments";
import { createConversation } from "@/lib/conversations";
import { setPendingMessage } from "@/lib/pending";

export const Route = createFileRoute("/_authenticated/chat/")({
  component: NewChat,
});

const ICONS = [Globe, Sigma, Code2, Table2];

function NewChat() {
  const { user } = Route.useRouteContext();
  const { data: profile } = useProfile(user.id);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function start(text: string, files: Parameters<typeof uploadAttachments>[0]) {
    const id = await createConversation(user.id);
    const uploaded = files.length ? await uploadAttachments(files, user.id, id) : [];
    setPendingMessage(id, { text, files: uploaded });
    queryClient.setQueryData(["messages", id], []);
    queryClient.invalidateQueries({ queryKey: ["conversations"] });
    await navigate({ to: "/chat/$threadId", params: { threadId: id } });
  }

  return (
    <div className="flex h-full flex-col items-center overflow-y-auto px-4 pb-10 pt-6 sm:justify-center sm:pt-0">
      <div className="portal-orb pointer-events-none mb-6 sm:mb-8" aria-hidden><span /><span /><span /></div>
      <div className="w-full max-w-3xl">
        <Greeting name={profile?.first_name} />
        <div className="mt-6 sm:mt-10">
          <Composer onSubmit={(m) => start(m.text, m.files)} />
        </div>
        <div className="mt-5 grid gap-2 sm:grid-cols-2">
          {SUGGESTIONS.map((s, i) => {
            const Icon = ICONS[i] ?? Globe;
            return (
              <button
                key={s}
                onClick={() => start(s, [])}
                className="tilt-3d flex items-center gap-3 rounded-2xl border border-border bg-card/50 px-4 py-3 text-left text-sm text-muted-foreground hover:bg-card hover:text-foreground"
              >
                <Icon className="size-4 shrink-0 text-brand-cyan" />
                {s}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
