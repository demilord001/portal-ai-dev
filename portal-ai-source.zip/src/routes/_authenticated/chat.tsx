import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { Home, Menu, Plus } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { ChatSidebar } from "@/components/portal/ChatSidebar";
import { PortalLogo } from "@/components/portal/PortalLogo";
import { UserMenu } from "@/components/portal/UserMenu";
import { useProfile } from "@/hooks/use-auth";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({
    meta: [
      { title: "Chat — PORTAL.AI" },
      { name: "description", content: "Chat with PORTAL.AI: live web search, file understanding and saved history." },
      { property: "og:title", content: "Chat — PORTAL.AI" },
      { property: "og:description", content: "Your next-gen AI assistant workspace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ChatLayout,
});

function ChatLayout() {
  const { user } = Route.useRouteContext();
  const { data: profile } = useProfile(user.id);
  const [open, setOpen] = useState(false);

  return (
    <div className="flex h-dvh overflow-hidden bg-background">
      <aside className="hidden w-72 shrink-0 border-r border-sidebar-border bg-sidebar md:block">
        <div className="flex h-16 items-center px-5">
          <Link to="/"><PortalLogo /></Link>
        </div>
        <div className="h-[calc(100%-4rem)]">
          <ChatSidebar />
        </div>
      </aside>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left" className="w-80 border-sidebar-border bg-sidebar p-0">
          <SheetTitle className="flex h-16 items-center px-5"><PortalLogo /></SheetTitle>
          <div className="h-[calc(100%-4rem)]">
            <ChatSidebar onNavigate={() => setOpen(false)} />
          </div>
        </SheetContent>
      </Sheet>

      <div className="relative flex min-w-0 flex-1 flex-col">
        <div className="pointer-events-none absolute inset-x-0 top-0 -z-0 h-96 bg-aurora opacity-60" />
        <div className="chat-grid pointer-events-none absolute inset-0 -z-0" aria-hidden />
        <header className="relative z-10 flex h-14 shrink-0 border-b border-border/40 backdrop-blur-xl sm:h-16 items-center justify-between gap-2 px-3 sm:px-5">
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="rounded-full md:hidden" onClick={() => setOpen(true)} aria-label="Open chat history">
              <Menu />
            </Button>
            <Link to="/chat" className="md:hidden"><PortalLogo compact /></Link>
          </div>
          <nav className="flex items-center gap-1">
            <Button asChild variant="ghost" size="sm" className="rounded-full">
              <Link to="/chat"><Plus /> <span className="hidden sm:inline">New chat</span></Link>
            </Button>
            <Button asChild variant="ghost" size="sm" className="rounded-full">
              <Link to="/"><Home /> <span className="hidden sm:inline">Home</span></Link>
            </Button>
            <div className="ml-1">
              <UserMenu user={user} name={profile?.full_name || profile?.first_name} avatar={profile?.avatar_url} />
            </div>
          </nav>
        </header>
        <main className="relative z-10 min-h-0 flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
