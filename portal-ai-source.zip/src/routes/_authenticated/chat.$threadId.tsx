import { useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";

import { ChatWindow } from "@/components/portal/ChatWindow";
import { useProfile } from "@/hooks/use-auth";
import { messagesQuery } from "@/lib/conversations";

export const Route = createFileRoute("/_authenticated/chat/$threadId")({
  loader: ({ context, params }) => context.queryClient.ensureQueryData(messagesQuery(params.threadId)),
  component: Thread,
  errorComponent: () => (
    <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
      <p className="text-lg font-medium">This chat isn't available.</p>
      <Link to="/chat" className="text-sm text-muted-foreground underline-offset-4 hover:underline">
        Start a new chat
      </Link>
    </div>
  ),
  pendingComponent: () => (
    <div className="mx-auto max-w-3xl space-y-4 px-4 pt-10">
      {[0, 1, 2].map((i) => (
        <div key={i} className="h-16 animate-pulse rounded-2xl bg-secondary/60" />
      ))}
    </div>
  ),
});

function Thread() {
  const { threadId } = Route.useParams();
  const { user } = Route.useRouteContext();
  const { data: profile } = useProfile(user.id);
  const { data } = useSuspenseQuery(messagesQuery(threadId));
  return (
    <ChatWindow
      key={threadId}
      conversationId={threadId}
      userId={user.id}
      firstName={profile?.first_name}
      initialMessages={data}
    />
  );
}
